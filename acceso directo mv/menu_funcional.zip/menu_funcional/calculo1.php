<?php
    session_start();

    if(isset($_POST["inversion"])){
        $inversion = $_POST["inversion"];
    }else{
        $inversion = "";
    }
    if(isset($_POST["inversion"])){
        $anio = $_POST["anio"];
    }else{
        $anio = 0;
    }
    if(isset($_POST["inversion"]) && isset($_POST["anio"])){

        $_SESSION["invers"] = 2;
        //header("Location: menu.php");
        //die();
    }


    var_dump($_SESSION);
    