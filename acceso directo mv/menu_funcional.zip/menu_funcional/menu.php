<?php 
    session_start();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu de funciones</title>
</head>
<body>
    <form action = "calculo1.php" method = "POST">
        <label>Cantidad que desea invertir
            <input type = "text" name = "inversion">
            <p>a</p>
        </label>
        <label>Numero de años de la inversion
            <input type = "number" name ="anio">
        </label>
        <input type = "submit" name = "enviar">
    </form>
    <?php 
    $_SESSION['test'] = 'OK';
    var_dump($_SESSION);
        if(isset($_SESSION["invers"])){
            echo "hola";
        }
    ?>
</body>
</html>